export const products = [
    {
      id: 1,
      name: 'Selenium',
      price: 799,
      quantity: 2,
      status: 'in Stock',
      description: "this course help us to understand automation testing",
      imgaddress : "https://rahulshettyacademy.com/rs_admin/public/images/courses/selenium-webdriver-with-java-basics-advanced-interview-guide_1591014934_selenium.jpg"
    },
    {
      id: 2,
      name: 'Appium',
      price: 699,
      quantity: 4,
      status: '2 left',
      description: "this course help us to understand automation testing",
      imgaddress : "https://rahulshettyacademy.com/rs_admin/public/images/courses/cypress-modern-automation-testing-from-scratch-framework_1609261074_azure.jpg"
    },
    {
      id: 3,
      name: 'Devops',
      price: 299,
      quantity: 0,
      status: '4 left',
      description: "this course help us to understand automation testing",
      imgaddress : "https://rahulshettyacademy.com/rs_admin/public/images/courses/webservices-rest-api-testing-with-soapui_1591015296_soapui.jpg"
    }
  ];