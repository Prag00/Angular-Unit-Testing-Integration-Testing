export class Contact
{

firstName :string;
lastName : string;
email : string;
password : string;
}