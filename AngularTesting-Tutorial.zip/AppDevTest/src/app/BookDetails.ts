export interface BookDetails {

    book_name :string;
    isbn : string;
    aisle :number;
}